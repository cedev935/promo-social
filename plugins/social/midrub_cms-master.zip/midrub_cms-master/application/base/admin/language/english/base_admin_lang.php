<?php
$lang["admin_upload"] = "Upload";
$lang["admin_remove"] = "Remove";
$lang["admin_manage"] = "Manage";
$lang["admin_new_code"] = "New Code";
$lang["admin_update"] = "Update";
$lang["admin_enter_update_code"] = "Enter the update code ...";