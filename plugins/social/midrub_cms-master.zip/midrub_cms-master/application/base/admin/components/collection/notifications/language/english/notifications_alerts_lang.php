<?php
$lang["notifications_missing_some_alert_parameters"] = "Some alert's parameters missing.";
$lang["notifications_wrong_value_some_alert_parameters"] = "Some alert's parameters have wrong value.";
$lang["notifications_wrong_value_some_alert_fields"] = "Some alert's fields have wrong value.";
$lang["notifications_alert_fields_without_language"] = "Some alert's fields don't have the language option.";
$lang["notifications_banner_enabled_but_missing"] = "The alert's banner is enabled but the banner missing.";
$lang["notifications_alert_page_enabled_but_missing_title"] = "The alert's page is enabled but the page's title missing.";
$lang["notifications_alert_can_not_be_saved_wrong_parameters"] = "The alert can't be saved because it don't has a banner and even a page.";
$lang["notifications_alert_type_requires_banner"] = "The selected alert's type requires a banner.";
$lang["notifications_alert_was_saved"] = "The alert was saved successfully.";
$lang["notifications_alert_was_not_saved"] = "The alert was not saved successfully.";