<?php
$lang["changes_settings"] = "Settings";