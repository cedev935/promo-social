<?php
$lang["plugins"] = "Plugins";