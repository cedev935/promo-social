<?php
$lang["admin"] = "Administrator";