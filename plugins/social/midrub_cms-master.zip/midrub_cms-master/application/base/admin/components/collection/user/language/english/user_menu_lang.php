<?php
$lang["user"] = "User";
$lang["user_no_data_found_to_show"] = "No data found to show.";