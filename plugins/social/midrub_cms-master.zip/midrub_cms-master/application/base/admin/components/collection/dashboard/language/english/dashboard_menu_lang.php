<?php
$lang["dashboard"] = "Dashboard";