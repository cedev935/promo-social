<?php
$lang["profile"] = "My Profile";