<?php
$lang["frontend"] = "Frontend";