<?php
$lang["frontend_social_no_code_was_found"] = "The required code was not found.";
$lang["frontend_social_an_error_occurred"] = "An error occurred while processing your request.";
$lang["frontend_oauth_token_missing"] = "The oauth token missing.";
$lang["frontend_no_oauth_token_verifier_found"] = "No oauth token or verifier was found.";