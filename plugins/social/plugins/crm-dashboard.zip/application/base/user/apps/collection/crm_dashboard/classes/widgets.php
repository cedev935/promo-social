<?php
/**
 * Widgets Class
 *
 * This file loads the Widgets class with methods to process the widgets
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.4
 */

// Define the namespace
namespace CmsBase\User\Apps\Collection\Crm_dashboard\Classes;

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Widgets class loads the properties used to process the widgets
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.4
 */
class Widgets {
    
    /**
     * Contains and array with saved widgets
     *
     * @since 0.0.8.4
     */
    public static $the_widgets = array(),
    $the_widgets_order = array();

    /**
     * Initialise the Class
     *
     * @since 0.0.8.4
     */
    public function __construct() {
        
        // Assign the CodeIgniter super-object
        $this->CI =& get_instance();
        
    }

    /**
     * The public method set_widget adds the widgets widgets in the queue
     * 
     * @param string $widget_slug contains the widget's slug
     * @param array $widget_params contains the widget's parameters
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    public function set_widget($widget_slug, $widget_params) {

        // Verify if the widget has valid fields
        if ( !empty($widget_params['widget_name']) && !empty($widget_params['widget_description']) && !empty($widget_params['widget_icon']) && !empty($widget_params['widget_data']) ) {

            // Verify if position exists
            if ( empty($widget_params['widget_position']) ) {
                $widget_params['widget_position'] = 0;
            }

            // Set slug
            $widget_params['widget_slug'] = $widget_slug;

            self::$the_widgets[] = $widget_params;
            
        }

    } 

    /**
     * The public method the_widgets provides the widgets from the queue
     * 
     * @since 0.0.8.4
     * 
     * @return array with widgets or boolean false
     */
    public function the_widgets() {

        // Verify if $the_widgets_order is empty
        if ( !self::$the_widgets_order ) {

            // Get widgets
            $the_db_widgets = the_crm_db_widgets();

            // Set widgets
            self::$the_widgets_order = $the_db_widgets?$the_db_widgets:array();

        }

        // Verify if widgets exists
        if ( self::$the_widgets ) {

            // Prepare the widgets status
            $widgets_status = self::$the_widgets_order?array_column(self::$the_widgets_order, 'status', 'widget'):array();

            // Allowed widgets list
            $widgets_list = array();

            // List all widgets
            foreach ( self::$the_widgets as $the_widget ) {

                // Verify if the app exists in the database
                if ( !isset($widgets_status[$the_widget['widget_slug']]) ) {

                    // Verify if the widget is enabled by default
                    if ( empty($the_widget['widget_default_enabled']) ) {
                        continue;
                    }

                } else {

                    // Verify if the widget is enabled
                    if ( empty($widgets_status[$the_widget['widget_slug']]) && (md_the_data('loaded_app') !== 'crm_settings') ) {
                        continue;
                    } 
                    
                    // Update widget's position
                    $the_widget['widget_position'] = array_column(self::$the_widgets_order, 'widget_position', 'widget')[$the_widget['widget_slug']];

                }

                $widgets_list[] = $the_widget;

            }
            
            if ( $widgets_list ) {

                usort($widgets_list, $this->widgets_sorter('widget_position'));

                return $widgets_list;

            } else {

                return false;

            }

        } else {

            return false;

        }

    }

    /**
     * The protected method widgets_sorter sorts the widgets
     * 
     * @param string $position contains the position's value
     * 
     * @since 0.0.8.4
     * 
     * @return array with widgets
     */
    protected function widgets_sorter($position) {

        return function ($a, $b) use ($position) {

            return strnatcmp($a[$position], $b[$position]);

        };

    }

}

/* End of file widgets.php */