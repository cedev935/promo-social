<?php
/**
 * Ajax Controller
 *
 * This file processes the app's ajax calls
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
 */

// Define the page namespace
namespace CmsBase\User\Apps\Collection\Crm_dashboard\Controllers;

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

// Define the namespaces to use
use CmsBase\User\Apps\Collection\Crm_dashboard\Helpers as CmsBaseUserAppsCollectionCrm_dashboardHelpers;

// Require the Dashboard Functions Inc file
require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/dashboard_functions.php';

/*
 * Ajaz class processes the app's ajax calls
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
 */
class Ajax {
    
    /**
     * Class variables
     *
     * @since 0.0.8.3
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.3
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();

        // Load language
        $this->CI->lang->load( 'crm_dashboard_user', $this->CI->config->item('language'), FALSE, TRUE, CMS_BASE_USER_APPS_CRM_DASHBOARD );
        
    }

    /**
     * The public method crm_dashboard_quick_guides_by_category gets quick quides by categories
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    public function crm_dashboard_quick_guides_by_category() {

        // Get quick guides
        (new CmsBaseUserAppsCollectionCrm_dashboardHelpers\Quick_guides)->crm_dashboard_quick_guides_by_category();
        
    }

    /**
     * The public method crm_dashboard_get_search_results gets search results for dashboard
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    public function crm_dashboard_get_search_results() {

        // Get search results
        (new CmsBaseUserAppsCollectionCrm_dashboardHelpers\Search)->crm_dashboard_get_search_results();
        
    }

    /**
     * The public method crm_dashboard_reorder_widgets saves the widgets order
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    public function crm_dashboard_reorder_widgets() {

        // Save order
        (new CmsBaseUserAppsCollectionCrm_dashboardHelpers\Widgets)->crm_dashboard_reorder_widgets();
        
    }
    
}

/* End of file ajax.php */