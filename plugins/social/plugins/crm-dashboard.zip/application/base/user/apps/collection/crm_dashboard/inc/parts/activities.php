<?php
/**
 * Activities Functions Inc Parts
 *
 * This file contains the some functions which
 * should be called only when them are used
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
*/

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('create_crm_activity_from_parts')) {
    
    /**
     * The function create_crm_activity_from_parts creates a crm's activity
     * 
     * @param array $args contains the activity's parameters
     * 
     * @return array with response
     */
    function create_crm_activity_from_parts($args) {

        // Get CodeIgniter object instance
        $CI =& get_instance();

        // Verify if $args contains the required keys
        if ( isset($args['user_id']) && isset($args['activity_type']) && isset($args['for_id']) && !empty($args['metas']) ) {

            // Prepare the activity
            $activity_args = array(
                'user_id' => $args['user_id'],
                'activity_type' => $args['activity_type'],
                'for_id' => $args['for_id'],
                'created' => time()
            );

            // Save the activity by using the Base's Model
            $activity_id = $CI->base_model->insert('crm_activities', $activity_args);

            // Verify if $activity_id was saved
            if ( !$activity_id ) {

                // Return error message
                return array(
                    'success' => FALSE,
                    'message' => $CI->lang->line('crm_clients_the_activity_was_not_saved')
                );

            }

            // List metas
            foreach ( $args['metas'] as $meta ) {

                // Verify if meta has required parameters
                if ( isset($meta['meta_name']) && isset($meta['meta_value']) ) {

                    // Prepare the activity
                    $meta_args = array(
                        'activity_id' => $activity_id,
                        'meta_name' => $meta['meta_name'],
                        'meta_value' => $meta['meta_value']
                    );

                    // Verify if meta's extra exists
                    if ( !empty($meta['meta_extra']) ) {

                        // Set meta_extra
                        $meta_args['meta_extra'] = $meta['meta_extra'];

                    }

                    // Save the activity's meta by using the Base's Model
                    $meta_id = $CI->base_model->insert('crm_activities_meta', $meta_args);

                    // Verify if meta_id exists
                    if ( !$meta_id ) {
                        
                        // Delete the activity
                        crm_activity($activity_id, $args['user_id']);

                        // Return error message
                        return array(
                            'success' => FALSE,
                            'message' => $CI->lang->line('crm_clients_a_activity_meta_not_saved')
                        );
                        
                    }

                } else {

                    // Delete the activity
                    crm_activity($activity_id, $args['user_id']);

                    // Return error message
                    return array(
                        'success' => FALSE,
                        'message' => $CI->lang->line('crm_clients_no_valid_activity_meta')
                    );
                    
                }

            }

            // Delete the user's cache
            delete_crm_cache_cronology_for_user($args['user_id'], 'crm_clients_client_activities_list');
            delete_crm_cache_cronology_for_user($args['user_id'], 'crm_clients_role_activities_list');
            delete_crm_cache_cronology_for_user($args['user_id'], 'crm_team_member_activities_list');

            // Return success message
            return array(
                'success' => TRUE,
                'activity_id' => $activity_id
            );

        } else {

            // Return error message
            return array(
                'success' => FALSE,
                'message' => $CI->lang->line('crm_clients_no_valid_parameters')
            );

        }

    }

}

if ( !function_exists('delete_crm_activity_from_parts') ) {
    
    /**
     * The function delete_crm_activity_from_parts deletes an activity
     * 
     * @param integer $activity_id contains the activity's ID
     * @param integer $user_id contains the user's ID
     * 
     * @return boolean true or false
     */
    function delete_crm_activity_from_parts($activity_id, $user_id) {

        // Delete the activity
        if ( $CI->base_model->delete('crm_activities', array('activity_id' => $activity_id, 'user_id' => $user_id) ) ) {

            // Delete the activity's meta
            $CI->base_model->delete('crm_activities_meta', array('activity_id' => $activity_id) );

            // Delete the user's cache
            delete_crm_cache_cronology_for_user($args['user_id'], 'crm_clients_client_activities_list');
            delete_crm_cache_cronology_for_user($args['user_id'], 'crm_clients_role_activities_list');
            delete_crm_cache_cronology_for_user($args['user_id'], 'crm_team_member_activities_list');

            // Run the hook
            md_run_hook(
                'crm_delete_activity',
                array(
                    'activity_id' => $activity_id
                )
            );

            return true;

        } else {

            return false;

        }

    }

}

/* End of file activities.php */