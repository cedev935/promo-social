<?php
/**
 * Plans Inc
 *
 * PHP Version 7.2
 *
 * This files contains the hooks for
 * the User component from the admin Panel
 *
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://github.com/scrisoft/crm/blob/master/LICENSE.md CRM License
 * @link     https://www.midrub.com/
 */

 // Define the constants
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * The public md_set_plans_options registers the dashboard plans options
 * 
 * @since 0.0.8.3
 */
md_set_plans_options(

    array(
        'name' => $this->lang->line('crm_dashboard'),
        'icon' => md_the_admin_icon(array('icon' => 'dashboard')),
        'slug' => 'crm_dashboard',
        'fields' => array(
            array (
                'field_type' => 'checkbox',
                'field_slug' => 'app_crm_dashboard_enabled',
                'field_words' => array(
                    'field_title' => $this->lang->line('crm_dashboard_enable_app'),
                    'field_description' => $this->lang->line('crm_dashboard_if_is_enabled_plan')
                ),
                'field_params' => array(
                    'checked' => md_the_plan_feature('app_crm_dashboard_enabled', $this->input->get('plan_id'))?1:0
                )

            )
        )
    )
    
);

/* End of file plans.php */
