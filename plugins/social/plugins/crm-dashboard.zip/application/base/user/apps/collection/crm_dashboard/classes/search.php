<?php
/**
 * Search Class
 *
 * This file loads the Search class with methods to process the search's filters
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.4
 */

// Define the namespace
namespace CmsBase\User\Apps\Collection\Crm_dashboard\Classes;

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Search class loads the properties used to process the search's filters
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.4
 */
class Search {
    
    /**
     * Contains and array with saved filters
     *
     * @since 0.0.8.4
     */
    public static $the_filters = array();

    /**
     * Initialise the Class
     *
     * @since 0.0.8.4
     */
    public function __construct() {
        
        // Assign the CodeIgniter super-object
        $this->CI =& get_instance();

        // Verify if saved filters are empty
        if ( !self::$the_filters ) {

            // Load language
            $this->CI->lang->load( 'crm_dashboard_user', $this->CI->config->item('language'), FALSE, TRUE, CMS_BASE_USER_APPS_CRM_DASHBOARD );

            // Set everywhere
            self::$the_filters[] = array(
                'filter_icon' => md_the_user_icon(array('icon' => 'home_line')),
                'filter_name' => $this->CI->lang->line('crm_dashboard_everywhere'),
                'filter_slug' => 'everywhere',
                'filter_position' => 1
            );

        }
        
    }

    /**
     * The public method set_filter adds the search filters in the queue
     * 
     * @param string $filter_slug contains the filter's slug
     * @param array $filter_params contains the filter's parameters
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    public function set_filter($filter_slug, $filter_params) {

        // Verify if the filter has valid fields
        if ( !empty($filter_params['filter_name']) && !empty($filter_params['filter_icon']) && !empty($filter_params['filter_search_data']) ) {

            // Verify if position exists
            if ( empty($filter_params['filter_position']) ) {
                $filter_params['filter_position'] = 0;
            }

            // Set slug
            $filter_params['filter_slug'] = $filter_slug;

            self::$the_filters[] = $filter_params;
            
        }

    } 

    /**
     * The public method the_filters provides the filters from the queue
     * 
     * @since 0.0.8.4
     * 
     * @return array with filters or boolean false
     */
    public function the_filters() {

        // Verify if filters exists
        if ( self::$the_filters ) {

            // Sort the filters
            usort(self::$the_filters, $this->filters_sorter('filter_position'));

            return self::$the_filters;

        } else {

            return false;

        }

    }

    /**
     * The protected method filters_sorter sorts the filters
     * 
     * @param string $position contains the position's value
     * 
     * @since 0.0.8.4
     * 
     * @return array with filters
     */
    protected function filters_sorter($position) {

        return function ($a, $b) use ($position) {

            return strnatcmp($a[$position], $b[$position]);

        };

    }

}

/* End of file search.php */