<?php
/**
 * Admin Inc
 *
 * PHP Version 7.2
 *
 * This files contains the hooks for
 * the User and Frontend component from the admin Panel
 *
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://github.com/scrisoft/crm/blob/master/LICENSE.md CRM License
 * @link     https://www.midrub.com/
 */

 // Define the constants
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * The public method md_set_admin_app_options registers options for Admin's
 * 
 * @since 0.0.8.3
 */
md_set_admin_app_options(
    'crm_dashboard',
    array (
            
        array(
            'field_slug' => 'app_crm_dashboard_enabled',
            'field_type' => 'checkbox',
            'field_words' => array(
                'field_title' => $this->lang->line('crm_dashboard_enable_app'),
                'field_description' => $this->lang->line('crm_dashboard_if_is_enabled')
            ),
            'field_params' => array(
                'checked' => md_the_option('app_crm_dashboard_enabled')?1:0
            )

        ),
        array(
            'field_slug' => 'app_crm_dashboard_quick_guide',
            'field_type' => 'checkbox',
            'field_words' => array(
                'field_title' => $this->lang->line('crm_dashboard_quick_guide'),
                'field_description' => $this->lang->line('crm_dashboard_quick_guide_description')
            ),
            'field_params' => array(
                'checked' => md_the_option('app_crm_dashboard_quick_guide')?1:0
            )

        )
        
    )

);

/**
 * The public method md_set_contents_category sets the Quick Guide contents category
 * 
 * @since 0.0.8.3
 */
md_set_contents_category(
    'quick_guides',
    array(
        'category_name' => $this->lang->line('crm_dashboard_quick_guide'),
        'category_icon' => md_the_admin_icon(array('icon' => 'quick_guide')),
        'editor' => true,
        'slug_in_url' => false,
        'templates_path' => CMS_BASE_USER_APPS_CRM_DASHBOARD . 'quick-guides/',
        'words_list' => array(
            'new_content' => $this->lang->line('crm_dashboard_new_guide'),
            'search_content' => $this->lang->line('crm_dashboard_search_guides'),
            'enter_content_title' => $this->lang->line('crm_dashboard_enter_guide_title')
        )
    )
);

 /**
 * The public method md_set_contents_category_option sets option for the Themes contents category
 * 
 * @since 0.0.8.3
 */
md_set_contents_category_option(
    'quick_guides',
    array(
        'name' => $this->lang->line('crm_dashboard_categories'),
        'slug' => 'quick_guides_categories',
        'fields' => array(
            array(
                'slug' => 'guides_categories',
                'type' => 'contents_classification',
                'label' => $this->lang->line('crm_dashboard_selected_categories'),
                'parent' => true,
                'fields' => array(
                    array(
                        'slug' => 'icon',
                        'type' => 'text',
                        'placeholder' => $this->lang->line('crm_dashboard_enter_icon_code')
                    )
                ),
                'words_list' => array(
                    'single_item' => $this->lang->line('crm_dashboard_classification_single_item'),
                    'search_input_placeholder' => $this->lang->line('crm_dashboard_search_for_categories'),
                    'new_classification_option' => $this->lang->line('crm_dashboard_new_category'),
                    'classification_name_input_placeholder' => $this->lang->line('crm_dashboard_enter_category_name'),
                    'classification_slug_input_placeholder' => $this->lang->line('crm_dashboard_enter_category_slug')
                )
            )                     
        ),
        'css_urls' => array(),
        'js_urls' => array() 
    )    
);

/**
 * The public method frontend_content_updated registers a hook
 * 
 * @param array $args contains the parameters
 * 
 * @since 0.0.8.3
 */
md_set_hook('frontend_content_updated', function($args) {

    // Verify if content's ID exists
    if ( !empty($args['content_id']) ) {

        // Use the base model for a simply sql query
        $get_content = $this->base_model->the_data_where(
            'contents',
            'contents_category',
            array(
                'content_id' => $args['content_id'],
                'contents_category' => 'quick_guides'
            )
        );

        // Verify if the content was found
        if ( $get_content ) {
            
            // Delete the quick_guides
            delete_crm_cache_cronology('quick_guides');

        }

    }

});

/* End of file admin.php */