<?php
/**
 * Settings Inc
 *
 * This file contains the functions
 * used for CRM Dashboard app in the CRM Settings app
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
 */

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

// Verify if the app is enabled
if ( md_the_option('app_crm_dashboard_enabled') && md_the_plan_feature('app_crm_dashboard_enabled') ) {

    // Set general's tab
    set_crm_settings_general_tab(
        'crm_dashboard_general_dashboard_tab',
        array(
            'name' => $this->lang->line('crm_dashboard'),
            'icon' => md_the_user_icon(array('icon' => 'dashboard')),
            'position' => 1
        )
    );

    // Set general's tab option
    set_crm_settings_general_tab_option (
        'crm_dashboard_general_dashboard_tab',
        array(
            'template_slug' => 'category',
            'slug' => 'crm_dashboard_general_clients_tab_main_category',
            'label' => $this->lang->line('crm_dashboard_main'),
            'position' => 1
        )
    );

    // Set general's tab option
    set_crm_settings_general_tab_option (
        'crm_dashboard_general_dashboard_tab',
        array(
            'template_slug' => 'checkbox_input',
            'slug' => 'crm_dashboard_disable_search',
            'label' => $this->lang->line('crm_dashboard_disable_search'),
            'label_description' => $this->lang->line('crm_dashboard_disable_search_description'),
            'position' => 2
        )
    );

    // Set general's tab option
    set_crm_settings_general_tab_option (
        'crm_dashboard_general_dashboard_tab',
        array(
            'template_slug' => 'checkbox_input',
            'slug' => 'crm_dashboard_disable_quick_guide',
            'label' => $this->lang->line('crm_dashboard_disable_quick_guide'),
            'label_description' => $this->lang->line('crm_dashboard_disable_quick_guide_description'),
            'position' => 3
        )
    );

    // Set general's tab option
    set_crm_settings_general_tab_option (
        'crm_dashboard_general_dashboard_tab',
        array(
            'template_slug' => 'checkbox_input',
            'slug' => 'crm_dashboard_block_widgets',
            'label' => $this->lang->line('crm_dashboard_block_widgets'),
            'label_description' => $this->lang->line('crm_dashboard_block_widgets_description'),
            'position' => 4
        )
    );

}

/* End of file settings.php */