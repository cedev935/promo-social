<?php
/**
 * CRM Dashboard Model
 *
 * PHP Version 7.3
 *
 * Crm_dashboard_model contains the CRM Dashboard Model
 *
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License
 * @link     https://www.midrub.com/
 */

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Crm_dashboard_model class - operates the crm_dashboard table
 *
 * @since 0.0.8.4
 * 
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License
 * @link     https://www.midrub.com/
 */
class Crm_dashboard_model extends CI_MODEL {
    
    /**
     * Class variables
     */
    private $table = 'crm_dashboard';

    /**
     * Initialise the model
     */
    public function __construct() {
        
        // Call the Model constructor
        parent::__construct();
        
        // Get crm_dashboard_widgets table
        $crm_dashboard_widgets = $this->db->table_exists('crm_dashboard_widgets');
        
        // Verify if the crm_dashboard_widgets table exists
        if ( !$crm_dashboard_widgets ) {
            
            // Create the crm_dashboard_widgets table
            $this->db->query('CREATE TABLE IF NOT EXISTS `crm_dashboard_widgets` (
                `widget_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                `user_id` int(11) NOT NULL,
                `widget` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
                `widget_position` int(4) NOT NULL,
                `status` tinyint(1) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
            
        }

        // Get crm_activities table
        $crm_activities = $this->db->table_exists('crm_activities');
                
        // Verify if the crm_activities table exists
        if ( !$crm_activities ) {
            
            // Create the crm_activities table
            $this->db->query('CREATE TABLE IF NOT EXISTS `crm_activities` (
                `activity_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                `user_id` bigint(20) NOT NULL,
                `activity_type` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
                `for_id` bigint(20) NOT NULL,
                `seen` tinyint(1) NOT NULL,
                `created` varchar(30) COLLATE utf8_unicode_ci NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
            
        }

        // Get crm_activities_meta table
        $crm_activities_meta = $this->db->table_exists('crm_activities_meta');
                
        // Verify if the crm_activities_meta table exists
        if ( !$crm_activities_meta ) {
            
            // Create the crm_activities_meta table
            $this->db->query('CREATE TABLE IF NOT EXISTS `crm_activities_meta` (
                `meta_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                `activity_id` bigint(20) NOT NULL,
                `meta_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
                `meta_value` text COLLATE utf8_unicode_ci NOT NULL,
                `meta_extra` text COLLATE utf8_unicode_ci NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
            
        }

        // Get crm_analytics_filters table
        $crm_analytics_filters = $this->db->table_exists('crm_analytics_filters');
                
        // Verify if the crm_analytics_filters table exists
        if ( !$crm_analytics_filters ) {
            
            // Create the crm_analytics_filters table
            $this->db->query('CREATE TABLE IF NOT EXISTS `crm_analytics_filters` (
                `filter_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                `user_id` bigint(20) NOT NULL,
                `filter_type` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
                `for_id` bigint(20) NOT NULL,
                `created` varchar(30) COLLATE utf8_unicode_ci NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
            
        }
        
        // Get crm_analytics_filters_meta table
        $crm_analytics_filters_meta = $this->db->table_exists('crm_analytics_filters_meta');
                
        // Verify if the crm_analytics_filters_meta table exists
        if ( !$crm_analytics_filters_meta ) {
            
            // Create the crm_analytics_filters_meta table
            $this->db->query('CREATE TABLE IF NOT EXISTS `crm_analytics_filters_meta` (
                `meta_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                `filter_id` bigint(20) NOT NULL,
                `meta_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
                `meta_value` text COLLATE utf8_unicode_ci NOT NULL,
                `meta_extra` text COLLATE utf8_unicode_ci NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
            
        }

        // Get crm_chronology table
        $crm_chronology = $this->db->table_exists('crm_chronology');
                
        // Verify if the crm_chronology table exists
        if ( !$crm_chronology ) {
            
            // Create the crm_chronology table
            $this->db->query('CREATE TABLE IF NOT EXISTS `crm_chronology` (
                `chronology_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                `user_id` bigint(20) NOT NULL,
                `chronology_type` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
                `for_id` bigint(20) NOT NULL,
                `created` varchar(30) COLLATE utf8_unicode_ci NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
            
        }

        // Get crm_chronology_meta table
        $crm_chronology_meta = $this->db->table_exists('crm_chronology_meta');
                
        // Verify if the crm_chronology_meta table exists
        if ( !$crm_chronology_meta ) {
            
            // Create the crm_chronology_meta table
            $this->db->query('CREATE TABLE IF NOT EXISTS `crm_chronology_meta` (
                `meta_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                `chronology_id` bigint(20) NOT NULL,
                `meta_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
                `meta_value` text COLLATE utf8_unicode_ci NOT NULL,
                `meta_extra` text COLLATE utf8_unicode_ci NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
            
        }

    }
    
}

/* End of file crm_dashboard_model.php */