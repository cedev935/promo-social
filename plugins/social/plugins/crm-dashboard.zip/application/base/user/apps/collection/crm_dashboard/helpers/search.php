<?php
/**
 * Search Helpers
 *
 * This file contains the class Search
 * with methods to load the search results for dashboard
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.4
 */

// Define the page namespace
namespace CmsBase\User\Apps\Collection\Crm_dashboard\Helpers;

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Search class provides the methods to load the search results for dashboard
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.4
*/
class Search {
    
    /**
     * Class variables
     *
     * @since 0.0.8.4
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.4
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();
        
    }

    /**
     * The public method crm_dashboard_get_search_results gets search results for dashboard
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    public function crm_dashboard_get_search_results() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('key', 'Key', 'trim');
            $this->CI->form_validation->set_rules('filter', 'Filter', 'trim|required');

            // Get data
            $key = $this->CI->input->post('key', TRUE);
            $filter = $this->CI->input->post('filter', TRUE);

            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // Gets all search filters
                $search_filters = the_crm_dashboard_search_filters();

                // Results container
                $results = array();

                // Verify if search filters exists
                if ( $search_filters ) {

                    // List the search filters
                    foreach ( $search_filters as $search_filter ) {

                        // Verify if filter is everywhere
                        if ( $filter === 'everywhere' ) {

                            // Verify if filter_search_data exists
                            if ( isset($search_filter['filter_search_data']) ) {

                                // Verify if function exists
                                if ( function_exists($search_filter['filter_search_data']) ) {

                                    // Get search data
                                    $the_search_data = $search_filter['filter_search_data'](array('key' => $key, 'limit' => 5, 'page' => 0));

                                    // Verify if search data exists
                                    if ( $the_search_data ) {

                                        // Set total
                                        $the_search_data['items'][0]['total'] = $the_search_data['total'];
                                        
                                        // Set results
                                        $results[$the_search_data['total'] . rand(1111, 1999)] = $the_search_data['items'][0];

                                    }

                                }

                            }

                        } else if ( $filter === $search_filter['filter_slug'] ) {

                            // Verify if filter_search_data exists
                            if ( !empty($search_filter['filter_search_data']) ) {

                                // Verify if function exists
                                if ( function_exists($search_filter['filter_search_data']) ) {

                                    // Get search data
                                    $the_search_data = $search_filter['filter_search_data'](array('key' => $key, 'limit' => 5, 'page' => 0));

                                    // Verify if search data exists
                                    if ( $the_search_data ) {
                                        
                                        // Set results
                                        $results = $the_search_data['items'];

                                    }                                    

                                }

                            }

                        }

                    }

                }

                // Verify if results exists
                if ( $results ) {

                    // Verify if filter is everywhere
                    if ( $filter === 'everywhere' ) {

                        // Order
                        krsort($results);

                        // Get array's values
                        $results = array_values($results);

                    }

                    // Prepare the success response
                    $data = array(
                        'success' => TRUE,
                        'items' => $results,
                        'words' => array(
                            'result' => $this->CI->lang->line('crm_dashboard_result'),
                            'results' => $this->CI->lang->line('crm_dashboard_results')
                        )
                    );

                    // Display the success response
                    echo json_encode($data);
                    exit();

                }

            }

        }
        
        // Prepare the false response
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('crm_dashboard_no_data_found')
        );

        // Display the false response
        echo json_encode($data);
        
    }

}

/* End of file search.php */