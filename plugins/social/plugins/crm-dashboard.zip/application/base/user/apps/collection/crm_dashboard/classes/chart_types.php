<?php
/**
 * Chart Types Class
 *
 * This file loads the Chart_types class with methods to process the analytics chart types
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
 */

// Define the namespace
namespace CmsBase\User\Apps\Collection\Crm_dashboard\Classes;

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Chart_types class loads the properties used to collect and process the analytics chart types
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
 */
class Chart_types {
    
    /**
     * Contains and array with saved types
     *
     * @since 0.0.8.3
     */
    public static $the_types = array(); 

    /**
     * The public method set_type adds type
     * 
     * @param string $type_slug contains the type's slug
     * @param array $args contains the type's arguments
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    public function set_type($type_slug, $args) {

        // Verify if the type has valid fields
        if ( isset($args['type_name']) && isset($args['css_urls']) && isset($args['js_urls']) ) {

            // If css_urls is not empty
            if ( !empty($args['css_urls']) ) {

                // List all css links
                foreach ($args['css_urls'] as $css_url) {

                    // Add css link in the queue
                    md_set_css_urls($css_url);

                }

            }

            // If js_urls is not empty
            if ( !empty($args['js_urls']) ) {

                // List all js links
                foreach ($args['js_urls'] as $js_url) {

                    // Add js link in the queue
                    md_set_js_urls($js_url);

                }

            }

            self::$the_types[][$type_slug] = $args;
            
        }

    } 

    /**
     * The public method load_types loads all apps types
     * 
     * @since 0.0.8.3
     * 
     * @return array with types or boolean false
     */
    public function load_types() {

        // Verify if types exists
        if ( self::$the_types ) {

            return self::$the_types;

        } else {

            return false;

        }

    }

}

/* End of file chart_types.php */