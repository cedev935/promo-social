<?php
/**
 * Cronology Functions Inc Parts
 *
 * This file contains the some functions which
 * should be called only when them are used
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
*/

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

if ( !function_exists('the_crm_cache_cronology_from_parts') ) {
    
    /**
     * The function the_crm_cache_cronology_from_parts gets all cache cronology
     * 
     * @return array with the cache cronology
     */
    function the_crm_cache_cronology_from_parts() {

        // Get the cache cronology
        $cache_cronology = md_the_cache('cache_cronology');

        // Verify if the cache cronology exists
        if ( !$cache_cronology ) {

            // Create the cache cronology
            md_create_cache('cache_cronology', array());

            // Set new cache cronology
            $cache_cronology = array();

        }

        return $cache_cronology;

    }

}

if (!function_exists('update_crm_cache_cronology_from_parts')) {
    
    /**
     * The function update_crm_cache_cronology_from_parts updates the cache cronology
     * 
     * @param string $cache_id contains identifier the for the cache
     * @param string $cache_value contains the cache's value.
     * 
     * @return void
     */
    function update_crm_cache_cronology_from_parts($cache_id, $cache_value) {

        // Get the cache cronology
        $cache_cronology = the_crm_cache_cronology_from_parts();

        // Verify if $cache_id exists
        if ( !isset($cache_cronology[$cache_id]) ) {
            $cache_cronology[$cache_id] = array();
        }

        // Set saved cronology
        $cache_cronology[$cache_id][] = $cache_value;

        // Save cache
        md_create_cache('cache_cronology', $cache_cronology);

    }

}

if ( !function_exists('delete_crm_cache_cronology_from_parts') ) {
    
    /**
     * The function delete_crm_cache_cronology_from_parts deletes the cache cronology
     * 
     * @param string $cache_id contains identifier the for the cache
     * 
     * @return void
     */
    function delete_crm_cache_cronology_from_parts($cache_id) {

        // Get the cache cronology
        $cache_cronology = the_crm_cache_cronology_from_parts();

        // Verify if the cache cronology exists
        if ( $cache_cronology ) {

            // Verify if $cache_id exists
            if ( isset($cache_cronology[$cache_id]) ) {

                // List all records
                foreach ( $cache_cronology[$cache_id] as $record ) {

                    // Delete the cache
                    md_delete_cache($record);

                }

                // Delete the cache cronology
                unset($cache_cronology[$cache_id]);

            }

        }

        // Save cache
        md_create_cache('cache_cronology', $cache_cronology);

    }

}

if ( !function_exists('the_crm_cache_cronology_from_parts_for_user_from_parts') ) {
    
    /**
     * The function the_crm_cache_cronology_from_parts_for_user_from_parts gets all cache cronology for a user
     * 
     * @param integer $user_id contains the user's ID
     * @param string $cache_id contains identifier the for the cache
     * 
     * @return array with the cache cronology
     */
    function the_crm_cache_cronology_from_parts_for_user_from_parts($user_id, $cache_id=NULL) {

        // Get the cache cronology
        $cache_cronology = md_the_cache('cache_cronology');

        // Verify if the cache cronology exists
        if ( !$cache_cronology ) {
            md_create_cache('cache_cronology', array());
        }

        // Verify if the users key exists
        if ( !isset($cache_cronology['users']) ) {
            $cache_cronology['users'] = array();
        }

        // Verify if the user exists
        if ( !isset($cache_cronology['users']['user_' . $user_id]) ) {
            $cache_cronology['users']['user_' . $user_id] = array();
            md_create_cache('cache_cronology', $cache_cronology);
        }  
        
        // Verify if $cache_id is not null
        if ( $cache_id ) {

            // Verify if the cache_id exists
            if ( !isset($cache_cronology['users']['user_' . $user_id][$cache_id]) ) {

                // Set user's cache
                $cache_cronology['users']['user_' . $user_id][$cache_id] = array();

                // Save the cache cronology
                md_create_cache('cache_cronology', $cache_cronology);

                return $cache_cronology['users']['user_' . $user_id][$cache_id];   

            }  else {

                return $cache_cronology['users']['user_' . $user_id][$cache_id];   

            }

        } else {

            return $cache_cronology['users']['user_' . $user_id];

        }

    }

}

if (!function_exists('update_crm_cache_cronology_for_user_from_parts')) {
    
    /**
     * The function update_crm_cache_cronology_for_user_from_parts updates the cache cronology for a user
     * 
     * @param integer $user_id contains the user's ID
     * @param string $cache_id contains identifier the for the cache
     * @param string $cache_value contains the cache's value.
     * 
     * @return void
     */
    function update_crm_cache_cronology_for_user_from_parts($user_id, $cache_id, $cache_value) {

        // Get the cache cronology
        $cache_cronology = the_crm_cache_cronology_from_parts();

        // Verify if cache_cronology exists
        if ( !isset($cache_cronology['cache_cronology']) ) {
            $cache_cronology['cache_cronology'] = array();
        }

        // Verify if the users key exists
        if ( !isset($cache_cronology['users']) ) {
            $cache_cronology['users'] = array();
        }

        // Verify if the user exists
        if ( !isset($cache_cronology['users']['user_' . $user_id]) ) {
            $cache_cronology['users']['user_' . $user_id] = array();
        }

        // Verify if the cache_id exists
        if ( !isset($cache_cronology['users']['user_' . $user_id][$cache_id]) ) {
            $cache_cronology['users']['user_' . $user_id][$cache_id] = array();           
        } 

        // Set user's cache
        $cache_cronology['users']['user_' . $user_id][$cache_id][] = $cache_value;

        // Save cache
        md_create_cache('cache_cronology', $cache_cronology);

    }

}

if ( !function_exists('delete_crm_cache_cronology_for_user_from_parts') ) {
    
    /**
     * The function delete_crm_cache_cronology_for_user_from_parts deletes the cache cronology
     * 
     * @param integer $user_id contains the user's ID
     * @param string $cache_id contains identifier the for the cache
     * 
     * @return void
     */
    function delete_crm_cache_cronology_for_user_from_parts($user_id, $cache_id=NULL) {

        // Get the cache cronology
        $cache_cronology = the_crm_cache_cronology_from_parts();

        // Verify if cache_cronology exists
        if ( !isset($cache_cronology['cache_cronology']) ) {
            $cache_cronology['cache_cronology'] = array();
        }

        // Verify if the users key exists
        if ( !isset($cache_cronology['users']) ) {
            $cache_cronology['users'] = array();
        }

        // Verify if the user exists
        if ( !isset($cache_cronology['users']['user_' . $user_id]) ) {
            $cache_cronology['users']['user_' . $user_id] = array();
        }

        // Verify if $cache_id exists
        if ( $cache_id ) {

            // Verify if the cache_id exists
            if ( isset($cache_cronology['users']['user_' . $user_id][$cache_id]) ) {

                // Verify if cache exists
                if ( $cache_cronology['users']['user_' . $user_id][$cache_id] ) {

                    // List all records
                    foreach ( $cache_cronology['users']['user_' . $user_id][$cache_id] as $record ) {

                        // Delete the cache
                        md_delete_cache($record);

                    }

                    // Delete the cache cronology
                    unset($cache_cronology['users']['user_' . $user_id][$cache_id]);

                }            

            } 

        } else {

            // Verify if cache exists
            if ( $cache_cronology['users']['user_' . $user_id] ) {

                // List all records
                foreach ( $cache_cronology['users']['user_' . $user_id] as $record ) {

                    // Delete the cache
                    md_delete_cache($record);

                }

                // Delete the cache cronology
                unset($cache_cronology['users']['user_' . $user_id]);

            } 

        }

        // Save cache
        md_create_cache('cache_cronology', $cache_cronology);

    }

}

/* End of file cronology.php */