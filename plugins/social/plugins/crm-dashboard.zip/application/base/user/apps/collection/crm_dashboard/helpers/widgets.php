<?php
/**
 * Widgets Helpers
 *
 * This file contains the class Widgets
 * with methods to manage the widgets for dashboard
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.4
 */

// Define the page namespace
namespace CmsBase\User\Apps\Collection\Crm_dashboard\Helpers;

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

// Require the Dashboard Functions Inc file
require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/dashboard_functions.php';

/*
 * Widgets class provides the methods to manage the widgets for dashboard
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.4
*/
class Widgets {
    
    /**
     * Class variables
     *
     * @since 0.0.8.4
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.4
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();

        // Load the CRM Dashboard Model
        $this->CI->load->ext_model( CMS_BASE_USER_APPS_CRM_DASHBOARD . 'models/', 'Crm_dashboard_model', 'crm_dashboard_model' );
        
    }

    /**
     * The public method crm_dashboard_reorder_widgets saves the widgets order
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    public function crm_dashboard_reorder_widgets() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('widgets', 'Widgets', 'trim');

            // Get data
            $widgets = $this->CI->input->post('widgets', TRUE);

            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // Get available widgets
                $the_available_widgets = the_crm_dashboard_widgets()?array_column(the_crm_dashboard_widgets(), 'widget_slug'):array();

                // Verify if widgets exists
                if ( $widgets ) {

                    // Reset all positions
                    $this->CI->base_model->update('crm_dashboard_widgets', array('user_id' => $this->CI->user_id), array('widget_position' => 0));

                    // Set position
                    $position = 1;

                    // List all widgets
                    foreach ( $widgets as $widget ) {

                        // Verify if the widget exists
                        if ( !in_array($widget, $the_available_widgets) ) {
                            continue;
                        }

                        // Get the widget's data from the database
                        $the_widget = $this->CI->base_model->the_data_where(
                            'crm_dashboard_widgets',
                            '*',
                            array(
                                'user_id' => $this->CI->user_id,
                                'widget' => $widget
                            )
                        );

                        // Verify if the preferences were saved
                        if ( $the_widget ) {

                            // Reset all positions
                            $this->CI->base_model->update('crm_dashboard_widgets', array('user_id' => $this->CI->user_id, 'widget' => $widget ), array('widget_position' => $position));

                        } else {

                            // Insert data
                            $insert = array(
                                'user_id' => $this->CI->user_id,
                                'widget' => $widget,
                                'widget_position' => $position,
                                'status' => 1  
                            );

                            // Insert data
                            $this->CI->base_model->insert('crm_dashboard_widgets', $insert);

                        }
                        
                        // Increase position
                        $position++;                    

                    }

                    
                    // Prepare the success response
                    $data = array(
                        'success' => TRUE
                    );

                    // Display the success response
                    echo json_encode($data);
                    exit();

                }

            }

        }
        
        // Prepare the false response
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('crm_dashboard_widgets_order_not_saved')
        );

        // Display the false response
        echo json_encode($data);
        
    }

}

/* End of file widgets.php */