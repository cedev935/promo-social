<?php
/**
 * CRM Dashboard App
 *
 * This file loads the Dashboard app
 *
 * @author Scrisoft
 * @package Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://github.com/scrisoft/crm/blob/master/LICENSE.md CRM License
 * @link     https://www.midrub.com/
 */

// Define the page namespace
namespace CmsBase\User\Apps\Collection\Crm_dashboard;

// Define the constants
defined('BASEPATH') OR exit('No direct script access allowed');
defined('CMS_BASE_USER_APPS_CRM_DASHBOARD') OR define('CMS_BASE_USER_APPS_CRM_DASHBOARD', CMS_BASE_USER . 'apps/collection/crm_dashboard/');
defined('CMS_BASE_USER_APPS_CRM_DASHBOARD_VERSION') OR define('CMS_BASE_USER_APPS_CRM_DASHBOARD_VERSION', '0.0.7');

// Define the namespaces to use
use CmsBase\User\Interfaces as CmsBaseUserInterfaces;
use CmsBase\User\Apps\Collection\Crm_dashboard\Controllers as CmsBaseUserAppsCollectionCrm_dashboardControllers;

/*
 * Main class loads the Dashboard app loader
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
 */
class Main implements CmsBaseUserInterfaces\Apps {
   
    /**
     * Class variables
     *
     * @since 0.0.8.3
     */
    protected
            $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.3
     */
    public function __construct() {
        
        // Assign the CodeIgniter super-object
        $this->CI =& get_instance();
        
    }

    /**
     * The public method check_availability checks if the app is available
     *
     * @return boolean true or false
     */
    public function check_availability() {

        // Verify if the app is enabled
        if ( !md_the_option('app_crm_dashboard_enabled') || !md_the_plan_feature('app_crm_dashboard_enabled') ) {
            return false;
        } else {
            return true;
        }
        
    }
    
    /**
     * The public method user loads the app's main page in the user panel
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    public function user() {
        
        // Verify if the app is enabled
        if ( !md_the_option('app_crm_dashboard_enabled') || !md_the_plan_feature('app_crm_dashboard_enabled') ) {
            show_404();
        }

        // Instantiate the class
        (new CmsBaseUserAppsCollectionCrm_dashboardControllers\User)->view();
        
    }
    
    /**
     * The public method ajax processes the ajax's requests
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    public function ajax() {
        
        // Verify if the app is enabled
        if ( !md_the_option('app_crm_dashboard_enabled') || !md_the_plan_feature('app_crm_dashboard_enabled') ) {

            // Prepare the error message
            $data = array(
                'success' => FALSE,
                'message' => $this->CI->lang->line('user_no_permissions_for_this_action')
            );
            
            // Display the error message
            echo json_encode($data);
            exit();       
            
        }        
        
        // Get action's get input
        $action = $this->CI->input->get('action', TRUE);

        // Verify if action exists
        if ( empty($action) ) {
            $action = $this->CI->input->post('action', TRUE);
        }

        try {
            
            // Call method if exists
            (new CmsBaseUserAppsCollectionCrm_dashboardControllers\Ajax)->$action();
            
        } catch (\Throwable $ex) {
            
            // Prepare the error message
            $data = array(
                'success' => FALSE,
                'message' => $ex->getMessage()
            );
            
            // Display the error message
            echo json_encode($data);
            
        }
        
    }

    /**
     * The public method rest processes the rest's requests
     * 
     * @param string $endpoint contains the requested endpoint
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    public function rest($endpoint) {

    }
    
    /**
     * The public method cron_jobs loads the cron jobs commands
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    public function cron_jobs() {
        
    }
    
    /**
     * The public method delete_account is called when user's account is deleted
     * 
     * @param integer $user_id contains the user's ID
     * 
     * @since 0.0.7.4
     * 
     * @return void
     */
    public function delete_account($user_id) {
        
    }
    
    /**
     * The public method hooks contains the app's hooks
     * 
     * @param string $category contains the hooks category
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    public function load_hooks( $category ) {

        // Set action
        $action = $this->CI->input->post('action', TRUE)?substr($this->CI->input->post('action', TRUE), 0, 13):'';

        // Verify if action parameter exists
        if ( $action === 'crm_dashboard' ) {

            // Set loaded app
            md_set_data('loaded_app', 'crm_dashboard');

        }

        // Register the hooks by category
        switch ( $category ) {

            case 'init':
                
                if ( $this->CI->uri->segment(2) === 'app-ajax' ) {

                    require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/dashboard_sessions.php';

                }
                
                // Require the Dashboard Init Inc file
                require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/dashboard_init.php';

                break;

            case 'user_init':

                // Load code only for CRM Settings
                if ( md_the_data('loaded_app') === 'crm_settings' ) {

                    // Load the settings app's language files
                    $this->CI->lang->load('crm_dashboard_settings', $this->CI->config->item('language'), FALSE, TRUE, CMS_BASE_USER_APPS_CRM_DASHBOARD);                
                    
                    // Require the Settings Inc file
                    md_get_the_file(CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/settings.php');

                } else if ( md_the_data('loaded_app') === 'crm_team' ) {

                    // Load the Members app's language file
                    $this->CI->lang->load('crm_dashboard_members', $this->CI->config->item('language'), FALSE, TRUE, CMS_BASE_USER_APPS_CRM_DASHBOARD);
                    
                    // Require the Members Inc
                    md_get_the_file(CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/members.php');

                }

                break;                

            case 'admin_init':

                // Register the hooks for administrator
                md_set_hook(
                    'admin_init',
                    function ($args) {

                        // Load the admin app's language files
                        $this->CI->lang->load('crm_dashboard_admin', $this->CI->config->item('language'), FALSE, TRUE, CMS_BASE_USER_APPS_CRM_DASHBOARD);

                        // Require the Admin Inc
                        md_get_the_file(CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/admin.php');

                        // Require the Plans Inc
                        md_get_the_file(CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/plans.php');


                    }

                );   

                break;

        }

    }

    /**
     * The public method guest contains the app's access for guests
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    public function guest() {

        // Verify if webhook exists
        if ( $this->CI->input->get('webhook') ) {

            // List all user's apps
            foreach (glob(APPPATH . 'base/user/apps/collection/*', GLOB_ONLYDIR) as $directory) {

                // Get the directory's name
                $app = trim(basename($directory) . PHP_EOL);

                // Verify if is crm dashboard
                if ( $app === 'crm_dashboard' ) {
                    continue;
                }

                // Create an array
                $array = array(
                    'CmsBase',
                    'User',
                    'Apps',
                    'Collection',
                    ucfirst($app),
                    'Main'
                );

                // Implode the array above
                $cl = implode('\\', $array);

                // Load the guest
                (new $cl())->guest();

            }

        }

    }
    
    /**
     * The public method app_info contains the app's info
     * 
     * @since 0.0.8.3
     * 
     * @return array with app's information
     */
    public function app_info() {

        // Load the app's language files
        $this->CI->lang->load( 'crm_dashboard_admin', $this->CI->config->item('language'), FALSE, TRUE, CMS_BASE_USER_APPS_CRM_DASHBOARD );
        
        // Return app information
        return array(
            'app_name' => $this->CI->lang->line('crm_dashboard'),
            'app_slug' => 'crm_dashboard',
            'app_icon' => md_the_admin_icon(array('icon' => 'dashboard')),
            'version' => CMS_BASE_USER_APPS_CRM_DASHBOARD_VERSION,
            'update_url' => 'https://raw.githubusercontent.com/scrisoft/crm/master/crm-dashboard-update',
            'update_code' => FALSE,
            'min_version' => '0.0.8.5',
            'max_version' => '0.0.8.5'
        );
        
    }

}

/* End of file main.php */