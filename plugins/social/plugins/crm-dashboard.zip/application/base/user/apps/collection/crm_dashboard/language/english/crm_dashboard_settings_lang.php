<?php
$lang["crm_dashboard"] = "Dashboard";
$lang["crm_dashboard_main"] = "Main";
$lang["crm_dashboard_disable_search"] = "Disable Search";
$lang["crm_dashboard_disable_search_description"] = "By enabling this option, the Search input from the Dashboard page will be removed.";
$lang["crm_dashboard_disable_quick_guide"] = "Disable Quick Guide";
$lang["crm_dashboard_disable_quick_guide_description"] = "By enabling this option, the Quick Guide from the Dashboard page will be removed.";
$lang["crm_dashboard_block_widgets"] = "Block Widgets";
$lang["crm_dashboard_block_widgets_description"] = "By enabling this option, the you and the team's members won't be able to change the widgets position.";
$lang["crm_dashboard_widgets"] = "Widgets";
$lang["crm_dashboard_disable_quick_reports"] = "Disable Quick Reports";
$lang["crm_dashboard_disable_quick_reports_description"] = "By default the Quick Reports widget is enabled. By enabling this option, the Quick Reports widget will be removed.";