<?php
/**
 * Dashboard Init Inc
 *
 * This file contains the general functions
 * which are used in the CRM Dashboard app
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
*/

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

// Define the namespaces to use
use CmsBase\User\Apps\Collection\Crm_dashboard\Classes as CmsBaseUserAppsCollectionCrm_dashboardClasses;

/*
|--------------------------------------------------------------------------
| DEFAULTS FUNCTIONS WHICH RETURNS DATA
|--------------------------------------------------------------------------
*/

if ( !function_exists('the_crm_cache_cronology') ) {
    
    /**
     * The function the_crm_cache_cronology gets all cache cronology
     * 
     * @return array with the cache cronology
     */
    function the_crm_cache_cronology() {

        // Require the Cronology Functions Inc Part
        require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/parts/cronology.php';   
        
        // Get cache
        return the_crm_cache_cronology_from_parts();  

    }

}

if ( !function_exists('the_crm_cache_cronology_for_user') ) {
    
    /**
     * The function the_crm_cache_cronology_for_user gets all cache cronology for a user
     * 
     * @param integer $user_id contains the user's ID
     * @param string $cache_id contains identifier the for the cache
     * 
     * @return array with the cache cronology
     */
    function the_crm_cache_cronology_for_user($user_id, $cache_id=NULL) {

        // Require the Cronology Functions Inc Part
        require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/parts/cronology.php';   
        
        // Get cache
        return the_crm_cache_cronology_for_user_from_parts($user_id, $cache_id);  

    }

}

if ( !function_exists('the_crm_date') ) {
    
    /**
     * The function the_crm_date generates the date based on the user wanted format
     * 
     * @param integer $user_id contains the user's ID
     * @param string $time contains the timestamp
     * 
     * @return string with current date
     */
    function the_crm_date($user_id, $time = 0) {

        // Verify if time is not 0
        if ( $time ) {

            return date('d/m/Y', $time);

        } else {

            return date('d/m/Y');

        }

    }

}

if ( !function_exists('the_crm_date_format') ) {
    
    /**
     * The function the_crm_date_format provides the user wanted date format
     * 
     * @param integer $user_id contains the user's ID
     * 
     * @return string with date format
     */
    function the_crm_date_format($user_id) {

        // Get date's format
        return md_the_user_option($user_id, 'user_date_format', $user_id)?md_the_user_option($user_id, 'user_date_format', $user_id):'dd/mm/yyyy';

    }

}

if ( !function_exists('the_crm_time_format') ) {
    
    /**
     * The function the_crm_time_format provides the user wanted time format
     * 
     * @param integer $user_id contains the user's ID
     * 
     * @return string with time format
     */
    function the_crm_time_format($user_id) {

        // Get time's format
        return md_the_user_option($user_id, 'user_time_format')?md_the_user_option($user_id, 'user_time_format'):'hh:ii';

    }

}

if ( !function_exists('the_crm_hours_format') ) {
    
    /**
     * The function the_crm_hours_format provides the user wanted hours format
     * 
     * @param integer $user_id contains the user's ID
     * 
     * @return string with hours format
     */
    function the_crm_hours_format($user_id) {

        // Get hours format
        return md_the_user_option($user_id, 'user_hours_format')?md_the_user_option($user_id, 'user_hours_format'):'24';

    }

}

if ( !function_exists('the_crm_calculate_time') ) {
    
    /**
     * The function the_crm_hours_format calculates the time
     * 
     * @param integer $user_id contains the user's ID
     * @param integer $time contains the user's time
     * 
     * @return string with time
     */
    function the_crm_calculate_time($user_id, $time) {

        // Time format
        $format = (the_crm_time_format($user_id) === 'hh:ii')?'h:i':'h:i:s';

        // Calculate time
        return (the_crm_hours_format($user_id) === '12')?date($format . ' a', $time):date(str_replace('h', 'H', $format), $time);

    }

}

if ( !function_exists('the_crm_first_week_day') ) {
    
    /**
     * The function the_crm_first_week_day provides the first day of the week
     * 
     * @return integer with day
     */
    function the_crm_first_week_day() {

        // Default
        return 1;

    }

}

if (!function_exists('the_crm_current_team_member')) {
    
    /**
     * The function the_crm_current_team_member gets the current team's member 
     * 
     * @return array with member's data
     */
    function the_crm_current_team_member() {

        // Require the Team Functions Inc Part
        require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/parts/team.php';   
        
        // Get member
        return the_crm_current_team_member_from_parts();  

    }

}

if ( !function_exists('the_crm_analytics_chart_types') ) {
    
    /**
     * The function the_crm_analytics_chart_types gets the chart types
     * 
     * @since 0.0.8.3
     * 
     * @return array with chart types or boolean false
     */
    function the_crm_analytics_chart_types() {
        
        // Call the chart_types class
        $chart_types = (new CmsBaseUserAppsCollectionCrm_dashboardClasses\Chart_types);

        // Return chart types
        return $chart_types->load_types();
        
    }
    
}

if (!function_exists('the_crm_widget_position')) {
    
    /**
     * The function the_crm_widget_position gets the widget's position
     * 
     * @param string $widget_slug
     * 
     * @since 0.0.8.4
     * 
     * @return integer or boolean false
     */
    function the_crm_widget_position($widget_slug) {

        // Require the Dashboard Functions Inc Part
        require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/dashboard_widgets.php';   
        
        // Get position
        return the_crm_widget_position_from_parts($widget_slug);  

    }

}

if (!function_exists('the_crm_user_session')) {
    
    /**
     * The function the_crm_user_session gets the user's session
     * 
     * @param string $user_id contains the user or member ID
     * 
     * @since 0.0.8.5
     * 
     * @return integer or boolean false
     */
    function the_crm_user_session($user_id) {

        // Get CodeIgniter object instance
        $CI =& get_instance();

        // Get the user's sessions
        $the_sessions = md_the_cache('crm_sessions_for_user_' . $user_id)?md_the_cache('crm_sessions_for_user_' . $user_id):array();

        // Verify if session exists
        if ( !empty($the_sessions[$user_id]) ) {
            return $the_sessions[$user_id];
        }

        return false;

    }

}

/*
|--------------------------------------------------------------------------
| DEFAULT FUNCTIONS TO SAVE DATA
|--------------------------------------------------------------------------
*/

if ( !function_exists('set_crm_analytics_chart_type') ) {
    
    /**
     * The function set_crm_analytics_chart_type registers analytics chart's types
     * 
     * @param string $type_slug contains the type's slug
     * @param array $args contains the type's arguments
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    function set_crm_analytics_chart_type($type_slug, $args) {
        
        // Call the chart_types class
        $chart_types = (new CmsBaseUserAppsCollectionCrm_dashboardClasses\Chart_types);

        // Set chart's type in the queue
        $chart_types->set_type($type_slug, $args);
        
    }
    
}

if ( !function_exists('set_crm_dashboard_search_filter') ) {
    
    /**
     * The function set_crm_dashboard_search_filter registers search's filters
     * 
     * @param string $filter_slug contains the filter's slug
     * @param array $filter_params contains the filter's parameters
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    function set_crm_dashboard_search_filter($filter_slug, $filter_params) {
        
        // Call the search class
        $search = (new CmsBaseUserAppsCollectionCrm_dashboardClasses\Search);

        // Set filter in the queue
        $search->set_filter($filter_slug, $filter_params);
        
    }
    
}

if ( !function_exists('set_crm_dashboard_widget') ) {
    
    /**
     * The function set_crm_dashboard_widget registers dashboard widgets
     * 
     * @param string $widget_slug contains the widget's slug
     * @param array $widget_params contains the widget's parameters
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    function set_crm_dashboard_widget($widget_slug, $widget_params) {
        
        // Call the widgets class
        $widgets = (new CmsBaseUserAppsCollectionCrm_dashboardClasses\Widgets);

        // Set widget in the queue
        $widgets->set_widget($widget_slug, $widget_params);
        
    }
    
}

/*
|--------------------------------------------------------------------------
| DEFAULT FUNCTIONS TO EXECUTE ACTIONS
|--------------------------------------------------------------------------
*/

if (!function_exists('update_crm_cache_cronology')) {
    
    /**
     * The function update_crm_cache_cronology updates the cache cronology
     * 
     * @param string $cache_id contains identifier the for the cache
     * @param string $cache_value contains the cache's value.
     * 
     * @return void
     */
    function update_crm_cache_cronology($cache_id, $cache_value) {

        // Require the Cronology Functions Inc Part
        require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/parts/cronology.php';   
        
        // Delete cache
        update_crm_cache_cronology_from_parts($cache_id, $cache_value);  

    }

}

if ( !function_exists('delete_crm_cache_cronology') ) {
    
    /**
     * The function delete_crm_cache_cronology deletes the cache cronology
     * 
     * @param string $cache_id contains identifier the for the cache
     * 
     * @return void
     */
    function delete_crm_cache_cronology($cache_id) {

        // Require the Cronology Functions Inc Part
        require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/parts/cronology.php';   
        
        // Delete cache
        delete_crm_cache_cronology_from_parts($cache_id);  

    }

}

if (!function_exists('update_crm_cache_cronology_for_user')) {
    
    /**
     * The function update_crm_cache_cronology_for_user updates the cache cronology for a user
     * 
     * @param integer $user_id contains the user's ID
     * @param string $cache_id contains identifier the for the cache
     * @param string $cache_value contains the cache's value.
     * 
     * @return void
     */
    function update_crm_cache_cronology_for_user($user_id, $cache_id, $cache_value) {

        // Require the Cronology Functions Inc Part
        require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/parts/cronology.php';   
        
        // Update cache
        update_crm_cache_cronology_for_user_from_parts($user_id, $cache_id, $cache_value);  

    }

}

if ( !function_exists('delete_crm_cache_cronology_for_user') ) {
    
    /**
     * The function delete_crm_cache_cronology_for_user deletes the cache cronology
     * 
     * @param integer $user_id contains the user's ID
     * @param string $cache_id contains identifier the for the cache
     * 
     * @return void
     */
    function delete_crm_cache_cronology_for_user($user_id, $cache_id=NULL) {

        // Require the Cronology Functions Inc Part
        require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/parts/cronology.php';   
        
        // Delete cache
        delete_crm_cache_cronology_for_user_from_parts($user_id, $cache_id);  

    }

}

if ( !function_exists('delete_crm_activity') ) {
    
    /**
     * The function delete_crm_activity deletes an activity
     * 
     * @param integer $activity_id contains the activity's ID
     * @param integer $user_id contains the user's ID
     * 
     * @return boolean true or false
     */
    function delete_crm_activity($activity_id, $user_id) {

        // Require the Activities Functions Inc Part
        require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/parts/activities.php';   
        
        // Delete
        return delete_crm_activity_from_parts($activity_id, $user_id);          

    }

}

if (!function_exists('create_crm_activity')) {
    
    /**
     * The function create_crm_activity creates a crm's activity
     * 
     * @param array $args contains the activity's parameters
     * 
     * @return array with response
     */
    function create_crm_activity($args) {

        // Require the Activities Functions Inc Part
        require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/parts/activities.php';   
        
        // Create
        return create_crm_activity_from_parts($args);  

    }

}

/* End of file dashboard_init.php */