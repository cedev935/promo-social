<?php
/**
 * Team Functions Inc Parts
 *
 * This file contains the some functions which
 * should be called only when them are used
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
*/

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('the_crm_current_team_member_from_parts')) {
    
    /**
     * The function the_crm_current_team_member_from_parts gets the current team's member 
     * 
     * @return array with member's data
     */
    function the_crm_current_team_member_from_parts() {

        // Get CodeIgniter object instance
        $CI =& get_instance();

        // Default member's ID
        $member_id = 0;

        // Default member's name
        $member_name = '';

        // Verify if member exists
        if ( $CI->session->userdata( 'member' ) ) {

            // Get the member
            $the_member = $CI->base_model->the_data_where(
                'teams',
                '*',
                array(
                    'user_id' => $CI->user_id,
                    'member_username' => $CI->session->userdata( 'member' )
                )
            );

            // Verify if the member exists
            if ( $the_member ) {

                // Set member's ID
                $member_id = $the_member[0]['member_id'];

                // Get members meta
                $get_metas = $CI->base_model->the_data_where('teams_meta', '*', array('member_id' => $member_id));

                // Verify if metas exists
                if ( $get_metas ) {

                    // List all metas
                    foreach ( $get_metas as $meta ) {

                        // Verify if meta_name is first_name or last_name
                        if ( ($meta['meta_name'] === 'first_name') || ($meta['meta_name'] === 'last_name') ) {

                            // Verify if the first name already exists 
                            if ( $member_name ) {

                                // Set last name
                                $member_name = $member_name . ' ' . $meta['meta_value'];

                            } else {

                                // Set first name
                                $member_name = $meta['meta_value'];

                            }

                        }

                    }
                    
                }

                // Verify if the member name exists
                if ( !$member_name ) {

                    // Set the member's name
                    $member_name = $CI->session->userdata( 'member' );

                }

            }

            // Return array
            return array(
                'member_id' => $member_id,
                'member_name' => $member_name,
                'role_id' => $the_member[0]['role_id']
            );               

        } else {

            // Gets current user's information
            $user_info = $CI->base_model->the_data_where('users', '*', array('user_id' => $CI->user_id));

            // Verify if the user has first and last name
            if ( $user_info[0]['first_name'] ) {

                // Set full name
                $member_name = $user_info[0]['first_name'] . ' ' . $user_info[0]['last_name'];

            } else {

                // Set username
                $member_name = $user_info[0]['username'];

            }

            // Return array
            return array(
                'member_id' => $member_id,
                'member_name' => $member_name
            );            

        }

    }

}

/* End of file team.php */