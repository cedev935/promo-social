<?php
/**
 * Quick Guides Helpers
 *
 * This file contains the class Quick_guides
 * with methods to load the quick guides and categories
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
 */

// Define the page namespace
namespace CmsBase\User\Apps\Collection\Crm_dashboard\Helpers;

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

// Define the namespaces to use
use CmsBase\Frontend\Classes as CmsBaseFrontendClasses;

// Require the Read Menu Inc file
require_once APPPATH . 'base/inc/menu/read_menu.php';

/*
 * Quick_guides class provides the methods to load the quick guides and categories
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
*/
class Quick_guides {
    
    /**
     * Class variables
     *
     * @since 0.0.8.3
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.3
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();

        // Load Base Classification Model
        $this->CI->load->ext_model(CMS_BASE_PATH . 'models/', 'Base_classifications', 'base_classifications');
        
    }

    /**
     * The public method crm_dashboard_quick_guides_by_category gets quick quides by categories
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    public function crm_dashboard_quick_guides_by_category() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('slug', 'Slug', 'trim|required');

            // Get data
            $slug = $this->CI->input->post('slug', TRUE);

            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // Response array
                $response = array();

                // Get categories
                $categories = $this->CI->base_model->the_data_where(
                    'classifications',
                    'classifications.classification_id, classifications_meta.meta_value as name, parent.meta_slug as parent_slug',
                    array(
                        'classifications_meta.meta_slug' => $slug,
                        'classifications_meta.meta_name' => 'name',
                        'classifications.classification_type' => 'contents_classification'
                    ),
                    array(),
                    array(),
                    array(
                        array(
                            'table' => 'classifications_meta',
                            'condition' => 'classifications.classification_id=classifications_meta.classification_id',
                            'join_from' => 'LEFT'
                        ),
                        array(
                            'table' => 'classifications_meta parent',
                            'condition' => "classifications.classification_parent=parent.classification_id AND parent.meta_name='name'",
                            'join_from' => 'LEFT'
                        )                        
                    )
                );

                // Verify if categories were found
                if ( $categories ) {

                    // Set parent slug
                    $response['parent_slug'] = $categories[0]['parent_slug'];

                    // Request the subcategories
                    $subcategories = md_the_classification(array(
                        'slug' => 'guides_categories',
                        'fields' => array('icon'),
                        'item_id' => $categories[0]['classification_id']
                    ));
                    
                    // Verify if subcategories exists
                    if ( $subcategories ) {

                        // Set subcategories
                        $response['categories'] = $subcategories;

                    } else {

                        // Set empty categories
                        $response['categories'] = array();

                    }

                    // Get the guides
                    $guides = (new CmsBaseFrontendClasses\Contents)->the_contents_list(array('classification_id' => $categories[0]['classification_id'], 'content_body' => TRUE));
                
                    // Verify if the guides were found
                    if ( $guides ) {

                        // Set guides
                        $response['guides'] = $guides;

                    } else {

                        // Set empty guides
                        $response['guides'] = array();

                    }

                    // Prepare success response
                    $data = array(
                        'success' => TRUE,
                        'response' => $response
                    );

                    // Display the success response
                    echo json_encode($data);

                }

            }

        }
        
    }

}

/* End of file quick_guides.php */