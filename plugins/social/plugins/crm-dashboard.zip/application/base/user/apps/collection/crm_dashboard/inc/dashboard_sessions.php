<?php
/**
 * Dashboard Sessions Inc
 *
 * This file contains the general functions
 * which are managing the active sessions
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.5
*/

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

// Define the namespaces to use
use CmsBase\User\Apps\Collection\Crm_dashboard\Classes as CmsBaseUserAppsCollectionCrm_dashboardClasses;

/*
|--------------------------------------------------------------------------
| DEFAULTS FUNCTIONS WHICH RETURNS DATA
|--------------------------------------------------------------------------
*/

if ( !function_exists('update_crm_user_sessions') ) {
    
    /**
     * The function update_crm_user_sessions updates the user's session
     * 
     * @return void
     */
    function update_crm_user_sessions() {

        // Get CodeIgniter object instance
        $CI =& get_instance();

        // Get the user's sessions
        $the_sessions = md_the_cache('crm_sessions_for_user_' . $CI->user_id)?md_the_cache('crm_sessions_for_user_' . $CI->user_id):array();

        // Verify if sessions exists
        if ( $the_sessions ) {

            // Delete cache
            md_delete_cache('crm_sessions_for_user_' . $CI->user_id);

        }

        // Verify if member exists
        if ( $CI->session->userdata( 'member' ) ) {

            // Require the Team Functions Inc Part
            require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/parts/team.php';   

            // Get team's member
            $the_member = the_crm_current_team_member_from_parts();

            // Update time
            $the_sessions['m_' . $the_member['member_id']] = time();

        } else {

            // Update time
            $the_sessions[$CI->user_id] = time();

        }

        // Save session
        md_create_cache('crm_sessions_for_user_' . $CI->user_id, $the_sessions);

    }

}

// Update sessions
update_crm_user_sessions();

/* End of file dashboard_sessions.php */