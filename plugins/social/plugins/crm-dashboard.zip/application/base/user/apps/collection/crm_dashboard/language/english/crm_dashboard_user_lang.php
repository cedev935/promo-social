<?php
$lang["crm_dashboard"] = "Dashboard";
$lang["crm_dashboard_search_for_something"] = "Search for something ...";
$lang["crm_dashboard_quick_guide"] = "Quick Guide";
$lang["crm_dashboard_error_occurred"] = "An error has occurred while processing the request.";
$lang["crm_dashboard_everywhere"] = "Everywhere";
$lang["crm_dashboard_no_data_found"] = "No data found to show.";
$lang["crm_dashboard_result"] = "result";
$lang["crm_dashboard_results"] = "results";
$lang["crm_dashboard_widgets_order_not_saved"] = "The widgets order was not saved successfully.";