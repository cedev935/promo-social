<?php
/**
 * Dashboard Functions Inc
 *
 * This file contains the general functions
 * which are used in the CRM Dashboard app
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
*/

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

// Define the namespaces to use
use CmsBase\User\Apps\Collection\Crm_dashboard\Classes as CmsBaseUserAppsCollectionCrm_dashboardClasses;

/*
|--------------------------------------------------------------------------
| DEFAULTS FUNCTIONS WHICH RETURNS DATA
|--------------------------------------------------------------------------
*/

if ( !function_exists('the_crm_dashboard_search_filters') ) {
    
    /**
     * The public method the_crm_dashboard_search_filters provides the filters from the queue
     * 
     * @since 0.0.8.4
     * 
     * @return array with filters or boolean false
     */
    function the_crm_dashboard_search_filters() {
        
        // Call the search class
        $search = (new CmsBaseUserAppsCollectionCrm_dashboardClasses\Search);

        // Return filters
        return $search->the_filters();
        
    }
    
}

if ( !function_exists('the_crm_dashboard_widgets') ) {
    
    /**
     * The public method the_crm_dashboard_widgets provides the widgets
     * 
     * @since 0.0.8.4
     * 
     * @return array with widgets or boolean false
     */
    function the_crm_dashboard_widgets() {
        
        // Call the widgets class
        $widgets = (new CmsBaseUserAppsCollectionCrm_dashboardClasses\Widgets);

        // Return widgets
        return $widgets->the_widgets();
        
    }
    
}

if ( !function_exists('the_crm_db_widgets') ) {
    
    /**
     * The public method the_crm_db_widgets provides all records from DB with widgets
     * 
     * @since 0.0.8.4
     * 
     * @return array with widgets or boolean false
     */
    function the_crm_db_widgets() {

        // Assign the CodeIgniter super-object
        $CI =& get_instance();
        
        // Get the widgets from the database
        return $CI->base_model->the_data_where(
            'crm_dashboard_widgets',
            '*',
            array(
                'user_id' => $CI->user_id
            )
        );
        
    }
    
}

/* End of file dashboard_functions.php */