<?php
/**
 * User Controller
 *
 * This file loads the CRM Dashboard app in the user panel
 *
 * @author Scrisoft
 * @package Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://github.com/scrisoft/crm/blob/master/LICENSE.md CRM License
 * @link     https://www.midrub.com/
 */

// Define the page namespace
namespace CmsBase\User\Apps\Collection\Crm_dashboard\Controllers;

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

// Require the Read Menu Inc file
require_once APPPATH . 'base/inc/menu/read_menu.php';

// Require the Dashboard Functions Inc file
require_once CMS_BASE_USER_APPS_CRM_DASHBOARD . 'inc/dashboard_functions.php';

/*
 * User class loads the CRM Dashboard app loader
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.3
 */
class User {
    
    /**
     * Class variables
     *
     * @since 0.0.8.3
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.3
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();
        
        // Load language
        $this->CI->lang->load( 'crm_dashboard_user', $this->CI->config->item('language'), FALSE, TRUE, CMS_BASE_USER_APPS_CRM_DASHBOARD );
        
    }
    
    /**
     * The public method view loads the app's template
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    public function view() {
        
        // Set the CRM Dashboard's Styles
        set_css_urls(array('stylesheet', base_url('assets/base/user/apps/collection/crm-dashboard/styles/css/main.css?ver=' . CMS_BASE_USER_APPS_CRM_DASHBOARD_VERSION), 'text/css', 'all'));
        
        // Set the CRM Dashboard Js
        set_js_urls(array(base_url('assets/base/user/apps/collection/crm-dashboard/js/main.js?ver=' . CMS_BASE_USER_APPS_CRM_DASHBOARD_VERSION)));

        // Set the Default Quick Guide Js
        set_js_urls(array(base_url('assets/base/user/default/js/libs/texts/quick-guide.js?ver=' . CMS_BASE_USER_APPS_CRM_DASHBOARD_VERSION)));        

        // Prepare view
        $this->set_user_view();
        
    }

    /**
     * The private method set_user_view sets user view
     * 
     * @since 0.0.8.3
     * 
     * @return void
     */
    private function set_user_view() {

        // Set the page's title
        set_the_title($this->CI->lang->line('crm_dashboard'));

        // Get the widgets
        $the_widgets = the_crm_dashboard_widgets();

        // Verify if the widgets exists
        if ( $the_widgets ) {

            // List all widgets
            foreach ( $the_widgets as $the_widget ) {

                // Verify if the page has the css_urls array
                if (isset($the_widget['css_urls'])) {

                    // Verify if the css_urls array is not empty
                    if ($the_widget['css_urls']) {

                        // List all css links
                        foreach ($the_widget['css_urls'] as $css_link_array) {

                            // Add css link in the queue
                            md_set_css_urls($css_link_array);

                        }

                    }

                }

                // Verify if the page has the js_urls array
                if (isset($the_widget['js_urls'])) {

                    // Verify if the js_urls array is not empty
                    if ($the_widget['js_urls']) {

                        // List all js links
                        foreach ($the_widget['js_urls'] as $js_link_array) {

                            // Add js link in the queue
                            md_set_js_urls($js_link_array);

                        }

                    }

                }

            }

        }

        // Set views params
        set_user_view(
            $this->CI->load->ext_view(
                CMS_BASE_USER_APPS_CRM_DASHBOARD . 'views',
                'main',
                array(
                    'widgets' => $the_widgets
                ),
                true
            )
        );

    }
    
}

/* End of file user.php */
