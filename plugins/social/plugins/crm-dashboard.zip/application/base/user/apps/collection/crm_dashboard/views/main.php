<section class="crm-dashboard-page">
    <div class="row">
        <div class="col-xl-6 offset-xl-3 col-md-10 offset-md-1 col-12 crm-dashboard-content">
            <?php if ( md_the_team_role_permission('crm_dashboard_search_access') ) { ?>
            <div class="card card-search">
                <div class="card-header">
                    <?php echo md_the_user_icon(array('icon' => 'search')); ?>
                    <input type="text" placeholder="<?php echo $this->lang->line('crm_dashboard_search_for_something'); ?>" autocomplete="off" class="form-control crm-dashboard-search-for-something" id="crm-dashboard-search-for-something">
                    <?php echo md_the_user_icon(array('icon' => 'loader', 'class' => 'crm-search-icon-loader')); ?>
                    <a href="#" class="cancel-search-for-something">
                        <?php echo md_the_user_icon(array('icon' => 'cancel')); ?>
                    </a>
                </div>
                <div class="card-body">
                    <ul class="nav nav-tabs" id="crm-dashboard-search-filters" role="tablist">
                        <?php
                        
                        // Verify if filters exists
                        if ( the_crm_dashboard_search_filters() ) {

                            // List filters
                            foreach ( the_crm_dashboard_search_filters() as $filter ) {

                                // Set active class
                                $active = (key(the_crm_dashboard_search_filters()[0]) === key($filter))?' active':'';

                                // Set selected
                                $selected = (key(the_crm_dashboard_search_filters()[0]) === key($filter))?'true':'false';

                                // Display the filter
                                echo '<li class="nav-item">'
                                    . '<a href="#crm-dashboard-search-input-' . $filter['filter_slug'] . '" role="tab" class="nav-link' . $active . '" id="crm-dashboard-search-input-' . $filter['filter_slug'] . '-tab" aria-controls="crm-dashboard-search-input-' . $filter['filter_slug'] . '" aria-selected="' . $selected . '" data-toggle="tab" data-filter="' . $filter['filter_slug'] . '">'
                                        . $filter['filter_name']
                                    . '</a>'
                                . '</li>';

                            }

                        }
                        
                        ?>          
                    </ul>
                    <div class="tab-content" id="crm-dashboard-search">
                        <?php 
                        
                        // Verify if filters exists
                        if ( the_crm_dashboard_search_filters() ) {

                            // List filters
                            foreach ( the_crm_dashboard_search_filters() as $filter ) {

                                // Set active class
                                $active = (key(the_crm_dashboard_search_filters()[0]) === key($filter))?' show active':'';

                                // Display the tab
                                echo '<div class="tab-pane fade' . $active . '" role="tabpanel" id="crm-dashboard-search-input-' . $filter['filter_slug'] . '" aria-labelledby="crm-dashboard-search-input-' . $filter['filter_slug'] . '-tab">'
                                    . '<ul class="list-group crm-dashboard-search-results">'
                                    . '</ul>'
                                . '</div>';

                            }

                        }
                        
                        ?>                         
                    </div>
                </div>
            </div>
            <?php } ?>
            <?php

            // Verify if the widgets exists
            if ( $widgets ) {

                // List all widgets
                foreach ( $widgets as $widget ) {

                    ?>
                    <div class="card card-item crm-dashboard-single-widget<?php echo md_the_team_role_permission('crm_dashboard_wigets_reorder')?'':' crm-dashboard-single-widget-blocked'; ?>" data-widget="<?php echo $widget['widget_slug']; ?>">
                        <div class="card-header">
                            <h3>
                                <?php echo $widget['widget_icon']; ?>
                                <?php echo $widget['widget_name']; ?>
                            </h3>
                        </div>
                        <div class="card-body">
                            <?php echo $widget['widget_data'](); ?>
                        </div>
                    </div>
                    <?php

                }

            }

            ?>
        </div>
    </div>
</section>
<?php if ( md_the_option('app_crm_dashboard_quick_guide') ) { ?>
    <?php md_get_the_file(CMS_BASE_USER . 'default/php/quick_guide.php'); ?>
<?php } ?>