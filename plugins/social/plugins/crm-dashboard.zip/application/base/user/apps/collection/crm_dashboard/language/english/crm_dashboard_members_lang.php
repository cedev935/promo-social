<?php
$lang["crm_dashboard"] = "Dashboard";
$lang["crm_dashboard_general"] = "General";
$lang["crm_dashboard_search_access"] = "Allow Search Access";
$lang["crm_dashboard_search_access_description"] = "The team's members with this role will be able to access the search input.";
$lang["crm_dashboard_wigets_reorder"] = "Allow Widgets Reorder";
$lang["crm_dashboard_wigets_reorder_description"] = "The team's members with this role will be able to reorder the widgets.";