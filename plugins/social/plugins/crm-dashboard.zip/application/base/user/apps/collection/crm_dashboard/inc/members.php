<?php
/**
 * Members Inc
 *
 * PHP Version 7.3
 *
 * This files contains the hooks for
 * the CRM Team App
 *
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License
 * @link     https://www.midrub.com/
 */

 // Define the constants
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * The public md_set_member_permissions registers the team's permissions
 * 
 * @since 0.0.8.4
 */
md_set_member_permissions(
    array(
        'name' => $this->lang->line('crm_dashboard'),
        'icon' => md_the_user_icon(array('icon' => 'dashboard')),
        'slug' => 'crm_dashboard',
        'fields' => array(
            array (
                'type' => 'category',
                'slug' => 'crm_dashboard_general_category',
                'label' => $this->lang->line('crm_dashboard_general')
            ),
            array (
                'type' => 'checkbox_input',
                'slug' => 'crm_dashboard_search_access',
                'label' => $this->lang->line('crm_dashboard_search_access'),
                'label_description' => $this->lang->line('crm_dashboard_search_access_description')
            ),
            array (
                'type' => 'checkbox_input',
                'slug' => 'crm_dashboard_wigets_reorder',
                'label' => $this->lang->line('crm_dashboard_wigets_reorder'),
                'label_description' => $this->lang->line('crm_dashboard_wigets_reorder_description')
            )
        ),
        'position' => 1

    )

);
