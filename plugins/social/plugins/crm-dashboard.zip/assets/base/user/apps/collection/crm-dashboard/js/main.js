/*
 * Main Dashboard JavaScript file
*/
jQuery(document).ready( function ($) {
    'use strict';

    // Get website url
    var url =  $('meta[name=url]').attr('content');
    
    /*******************************
    METHODS
    ********************************/

    /*
     * Gets search results
     * 
     * @since   0.0.8.4
     */
    Main.crm_dashboard_get_search_results = function() {      

        // Prepare data to send
        var data = {
            action: 'crm_dashboard_get_search_results',
            key: $('.crm-dashboard-page .crm-dashboard-search-for-something').val(),
            filter: $('.crm-dashboard-page .card-search #crm-dashboard-search-filters .nav-item .nav-link.active').attr('data-filter')
        };

        // Make ajax call
        Main.ajax_call(url + 'user/app-ajax/crm_dashboard', 'POST', data, 'crm_dashboard_display_search_response', 'ajax_onprogress');

        // Set progress bar
        Main.set_progress_bar();

    };

    /*
     * Reorder the widgets
     * 
     * @since   0.0.8.4
     */
    Main.crm_dashboard_reorder_widgets = function() {

        // Widgets container
        var all_widgets = [];

        // Get the widgets
        let widgets = $('.crm-dashboard-page .crm-dashboard-single-widget');

        // Verify if widgets exists
        if ( widgets.length > 0 ) {

            // List the widgets
            for ( var w = 0; w < widgets.length; w++ ) {

                // Add widget's slug to the container
                all_widgets.push($(widgets[w]).attr('data-widget'));

            }

            // Prepare data to send
            var data = {
                action: 'crm_dashboard_reorder_widgets',
                widgets: all_widgets
            };

            // Make ajax call
            Main.ajax_call(url + 'user/app-ajax/crm_dashboard', 'POST', data, 'crm_dashboard_reorder_widgets_response', 'ajax_onprogress');

            // Set progress bar
            Main.set_progress_bar();

        }

    };

    /*******************************
    ACTIONS
    ********************************/

    /*
     * Detect widget mouse down
     * 
     * @param object e with global object
     * 
     * @since   0.0.8.3
     */
    $(document).on('mousedown', '.crm-dashboard-page .crm-dashboard-single-widget .card-header h3', function(e) {

        // Verify if the widget is blocked
        if ( $(this).closest('.crm-dashboard-single-widget').hasClass('crm-dashboard-single-widget-blocked') ) {
            return;
        }

        // Verify if the widget is active
        if ( $('.crm-dashboard-page .crm-dashboard-single-widget-active').length > 0 ) {

            // Remove the active status
            $('.crm-dashboard-page .crm-dashboard-single-widget-active').remove();

        }

        // Remove active drag
        $('.crm-dashboard-page .crm-dashboard-single-widget').removeClass('card-drag-active');
        
        // Set active drag
        $(this).closest('.crm-dashboard-single-widget').addClass('card-drag-active');

        // Get width
        let width = $(this).closest('.crm-dashboard-single-widget').outerWidth();

        // Get height
        let height = $(this).closest('.crm-dashboard-single-widget').outerHeight();

        // Get top position
        let top = $(this).closest('.crm-dashboard-single-widget').offset().top;

        // Clone
        let copy = $(this).closest('.crm-dashboard-single-widget').clone();

        // Add active class
        copy.addClass('crm-dashboard-single-widget-active');

        // Append to
        copy.appendTo('.crm-dashboard-page .crm-dashboard-content');

        // Add top distance
        copy.attr('data-top', (e.pageY - top));

        // Set CSS
        $('.crm-dashboard-page .crm-dashboard-single-widget-active').css({
            'position': 'absolute',
            'z-index': '10',
            'top': top + 'px',
            'left': '0',
            'margin-top': '0',     
            'width': width + 'px',
            'height': height + 'px',
            'opacity': '0.3'
        });

        // Set body cursor
        $('body').css({
            'cursor': 'move'
        });

    });

    /*
     * Detect mouse move
     * 
     * @param object e with global object
     * 
     * @since   0.0.8.3
     */
    $(document).on('mousemove', 'body', function(e) {
        e.preventDefault();

        if ( $('.crm-dashboard-page .crm-dashboard-single-widget-active').length > 0 ) {

            // Get all widgets
            let widgets = $('.crm-dashboard-page .crm-dashboard-content > .crm-dashboard-single-widget');

            // Verify if widgets exists
            if ( widgets.length > 0 ) {

                // List all widgets
                for ( var w = 0; w < (widgets.length - 1); w++ ) {

                    if ( ( $(widgets[w]).offset().top <= e.pageY ) && ( e.pageY <= ( $(widgets[w]).offset().top + $(widgets[w]).outerHeight() ) ) ) {

                        if ( w < 1 ) {

                            if ( $(widgets[(w + 1)]).hasClass('card-drag-active') && ( $(widgets[w]).offset().top + 100) <= e.pageY ) {

                                $(widgets[w]).removeClass('card-drag-over-top');
                                $(widgets[w]).removeClass('card-drag-over-bottom');

                            } else {

                                if ( ( $(widgets[w]).offset().top + 100) >= e.pageY ) {

                                    if ( !$(widgets[w]).hasClass('card-drag-active') ) {
                                        $(widgets[w]).addClass('card-drag-over-top');
                                    }
    
                                    $(widgets[w]).removeClass('card-drag-over-bottom');
    
                                } else {
    
                                    $(widgets[w]).removeClass('card-drag-over-top');
    
                                    if ( !$(widgets[w]).hasClass('card-drag-active') ) {
                                        $(widgets[w]).addClass('card-drag-over-bottom');
                                    }
    
                                }

                            }

                        } else if ( w === (widgets.length - 2) ) {

                            $(widgets[w]).removeClass('card-drag-over-top');
                            
                            if ( !$(widgets[w]).hasClass('card-drag-active') ) {
                                $(widgets[w]).addClass('card-drag-over-bottom');
                            }                            

                        }  else if ( $(widgets[(w + 1)]).hasClass('card-drag-active') ) {

                            $(widgets[w]).removeClass('card-drag-over-top');
                            $(widgets[w]).removeClass('card-drag-over-bottom');

                        }else {

                            $(widgets[w]).removeClass('card-drag-over-top');

                            if ( !$(widgets[w]).hasClass('card-drag-active') ) {
                                $(widgets[w]).addClass('card-drag-over-bottom');
                            }

                        }

                    } else {

                        $(widgets[w]).removeClass('card-drag-over-top');
                        $(widgets[w]).removeClass('card-drag-over-bottom');

                    }

                }

            }

            // Set CSS
            $('.crm-dashboard-page .crm-dashboard-single-widget-active').css({
                'top': (e.pageY - $('.crm-dashboard-page .crm-dashboard-single-widget-active').attr('data-top')) + 'px'
            });

        } else {
            return;
        }

    });

    /*
     * Detect mouse up
     * 
     * @param object e with global object
     * 
     * @since   0.0.8.3
     */
    $(document).on('mouseup', 'body', function(e) {
        e.preventDefault();

        // Verify if active widget exists
        if ( $('.crm-dashboard-page .crm-dashboard-single-widget-active').length > 0 ) {

            // Set scale
            $('.crm-dashboard-page .card-drag-active').css({
                'transform': 'scale(0.7)'
            });        

            // Verify if dragover top exists
            if ( $('.crm-dashboard-page .crm-dashboard-content > .card-drag-over-top').length > 0 ) {

                // Copy dragged widget
                $('.crm-dashboard-page .card-drag-active').insertBefore('.crm-dashboard-page .crm-dashboard-content > .card-drag-over-top');


                // Remove over class
                $('.crm-dashboard-page .crm-dashboard-content > .crm-dashboard-single-widget').removeClass('card-drag-over-top');

            }            

            // Verify if dragover bottom exists
            if ( $('.crm-dashboard-page .crm-dashboard-content > .card-drag-over-bottom').length > 0 ) {

                // Copy dragged widget
                $('.crm-dashboard-page .card-drag-active').insertAfter('.crm-dashboard-page .crm-dashboard-content > .card-drag-over-bottom');

                // Remove over class
                $('.crm-dashboard-page .crm-dashboard-content > .crm-dashboard-single-widget').removeClass('card-drag-over-bottom');

            }

            // Schedule event
            setTimeout(function() {

                // Remove scale
                $('.crm-dashboard-page .card-drag-active').css({
                    'transform': 'scale(1)'
                });                
                // Remove active drag
                $('.crm-dashboard-page .crm-dashboard-single-widget').removeClass('card-drag-active');

                // Reorder the widgets
                Main.crm_dashboard_reorder_widgets();

            }, 100);  

            // Remove active widget
            $('.crm-dashboard-page .crm-dashboard-single-widget-active').remove();

            // Removy body cursor
            $('body').css({
                'cursor': ''
            });

        } else {
            return;
        }

    });

    /*
     * Search for something
     * 
     * @param object e with global object
     * 
     * @since   0.0.8.3
     */
    $(document).on('keyup', '.crm-dashboard-page .crm-dashboard-search-for-something', function (e) {
        e.preventDefault();

        // Set this
        let $this = $(this);

        // Verify if input has a value
        if ( $(this).val() !== '' ) {

            // Verify if an event was already scheduled
            if ( typeof Main.queue !== 'undefined' ) {

                // Clear previous timout
                clearTimeout(Main.queue);

            }
            
            // Verify if loader icon has style
            if ( !$this.closest('div').find('.crm-search-icon-loader').attr('style') ) {

                // Set opacity
                $this.closest('div').find('.crm-search-icon-loader').fadeTo( 'slow', 1.0);

            }

            Main.schedule_event(function() {

                // Set opacity
                $this.closest('div').find('.crm-search-icon-loader').removeAttr('style');         

                // Set opacity
                $this.closest('div').find('a').fadeTo( 'slow', 1.0);

                // Show search
                $this.closest('.card-search').find('.card-body').slideDown('fast');

                // Gets search's results
                Main.crm_dashboard_get_search_results();  

            }, 1000);

        } else {

            // Set opacity
            $this.closest('div').find('a').removeAttr('style');

            // Gets search's results
            Main.crm_dashboard_get_search_results();  
            
        }

    });

    /*
     * Cancel the search for something
     * 
     * @param object e with global object
     * 
     * @since   0.0.8.4
     */     
    $('.crm-dashboard-page .card-search a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        e.target;

        // Gets search's results
        Main.crm_dashboard_get_search_results();  

    });

    /*
     * Cancel the search for something
     * 
     * @param object e with global object
     * 
     * @since   0.0.8.3
     */ 
    $( document ).on( 'click', '.crm-dashboard-page .cancel-search-for-something', function (e) {
        e.preventDefault();

        // Set opacity
        $(this).removeAttr('style');   

        // Empty the search
        $('.crm-dashboard-page .crm-dashboard-search-for-something').val('');            
        
        // Hide search
        $('.crm-dashboard-page .card-search').find('.card-body').slideUp('fast');        
        
    });
   
    /*******************************
    RESPONSES
    ********************************/

    /*
     * Display the search response
     * 
     * @param string status contains the response status
     * @param object data contains the response content
     * 
     * @since   0.0.8.4
     */
    Main.methods.crm_dashboard_display_search_response = function ( status, data ) {

        // Remove progress bar
        Main.remove_progress_bar();

        // Verify if the success response exists
        if ( status === 'success' ) {
            
            // Items container
            var items = '';

            // List all items
            for ( var i = 0; i < data.items.length; i++ ) {

                // Set results
                let results = '';

                // Verify if total exists
                if ( typeof data.items[i].total !== 'undefined' ) {

                    // Set results word
                    let results_word = (data.items[i].total > 1)?data.words.results:data.words.result;

                    // Set results
                    results = '<span class="o-' + i + '">' + data.items[i].total + ' ' + results_word + '</span>';

                }

                // Add item to the container
                items += '<li class="list-group-item">'
                    + '<div class="row">'
                        + '<div class="col-8 media">'
                            + '<span class="mr-3 name-cover">'
                                + data.items[i].item_icon
                            + '</span>'
                            + '<div class="media-body">'
                                + '<h5 class="mt-0 mb-1">'
                                    + '<a href="' + data.items[i].item_link + '">'
                                        + data.items[i].item_name
                                    + '</a>'
                                    + '<span>'
                                        + data.items[i].item_description
                                    + '</span>'
                                + '</h5>'
                            + '</div>'
                        + '</div>'
                        + '<div class="col-4 crm-dashboard-found-results">'
                            + '<div>'
                                + results
                            + '</div>'
                        + '</div>'
                    + '</div>'
                + '</li>';

                // Only 5 results
                if ( i > 4 ) {
                    break;
                }

            }

            // Display items
            $('.crm-dashboard-page .card-search .tab-pane.active .crm-dashboard-search-results').html(items);
            
        } else {
            
            // Create the no items message
            let no_items = '<li class="list-group-item alert alert-primary">'
                + data.message
            + '</li>';

            // Display the no items message
            $('.crm-dashboard-page .card-search .tab-pane.active .crm-dashboard-search-results').html(no_items);            

        }
        
    };

    /*
     * Display the widgets reorder response
     * 
     * @param string status contains the response status
     * @param object data contains the response content
     * 
     * @since   0.0.8.4
     */
    Main.methods.crm_dashboard_reorder_widgets_response = function ( status, data ) {

        // Remove progress bar
        Main.remove_progress_bar();

        // Verify if the success response exists
        if ( status !== 'success' ) {
            
            // Display alert
            Main.popup_fon('sube', data.message, 1500, 2000);

        }
        
    };

});