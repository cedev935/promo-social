/*
 * Main JavaScript file
*/
jQuery(document).ready( function ($) {
    'use strict';

    // Variables
    var Main = {};

    /*
     * Schedule event
     * 
     * @param funcion fun contains the function
     * @param integer interval contains time
     */
    Main.schedule_event = function($fun, interval) {

        // Add to queue
        Main.queue = setTimeout($fun, interval);
        
    };

    /*******************************
    ACTIONS
    ********************************/

    /*
     * Search for articles
     * 
     * @param object e with global object
     */
    $(document).on('keyup', 'body .doc-search-for-articles', function (e) {
        e.preventDefault();

        // Remove the selected class
        $('body .doc-page-show').removeClass('doc-main-menu-item-selected');

        // Set this
        let $this = $(this);

        // Verify if input has a value
        if ( $(this).val() !== '' ) {

            // Verify if an event was already scheduled
            if ( typeof Main.queue !== 'undefined' ) {

                // Clear previous timout
                clearTimeout(Main.queue);

            }
            
            // Verify if loader icon has style
            if ( !$this.closest('div').find('.doc-search-icon-loader').attr('style') ) {

                // Set opacity
                $this.closest('div').find('.doc-search-icon-loader').fadeTo( 'slow', 1.0);

            }

            Main.schedule_event(function() {

                // Set opacity
                $this.closest('div').find('.doc-search-icon-loader').removeAttr('style');         

                // Set opacity
                $this.closest('div').find('a').fadeTo( 'slow', 1.0);

                // Get value
                var value = $this.val().toLowerCase();

                // List articles
                $('.doc-articles > article').filter(function () {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });

                // Scroll the page
                $('.doc-articles').animate({
                    scrollTop: 0
                }, 100);

            }, 1000);

        } else {

            // Set opacity
            $this.closest('div').find('a').removeAttr('style');

            // Get value
            var value = $this.val().toLowerCase();
            
            // List articles
            $('.doc-articles > article').filter(function () {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });

            // Add the selected class
            $('body .doc-page-show').eq(0).addClass('doc-main-menu-item-selected');

            // Scroll the page
            $('.doc-articles').animate({
                scrollTop: 0
            }, 100);
            
        }

    });

    /*
     * Cancel the search
     * 
     * @param object e with global object
     */ 
    $( document ).on( 'click', 'body .doc-cancel-search', function (e) {
        e.preventDefault();

        // Empty search input
        $('body .doc-search-for-articles').val('');

        // Set opacity
        $(this).closest('div').find('a').removeAttr('style');

        // Get value
        var value = $(this).val().toLowerCase();
        
        // List articles
        $('.doc-articles > article').filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });

        // Add the selected class
        $('body .doc-page-show').eq(0).addClass('doc-main-menu-item-selected');

        // Scroll the page
        $('.doc-articles').animate({
            scrollTop: 0
        }, 100);
        
    });

    /*
     * Expand or collapse the menu
     * 
     * @param object e with global object
     */ 
    $( document ).on( 'click', 'body .doc-sidebar-header .navbar-toggler', function (e) {
        e.preventDefault();

        // Verify if the menu is hidden
        if ( $('body .doc-sidebar-body').hasClass('hidden') ) {

            // Show
            $('body .doc-sidebar-body').slideDown('slow', function () {

                // Remove hidden class
                $('body .doc-sidebar-body').removeClass('hidden');

            });

        } else {

            // Hide
            $('body .doc-sidebar-body').slideUp('slow', function () {

                // Add hidden class
                $('body .doc-sidebar-body').addClass('hidden');

            });

        }
        
    });

    /*
     * Expand or collapse the submenu
     * 
     * @param object e with global object
     */ 
    $( document ).on( 'click', 'body .doc-main-menu .doc-main-menu-item a', function (e) {
        e.preventDefault();

        // This
        let $this = $(this);

        // Verify if the link is for dropdown
        if ( $(this).closest('div').hasClass('doc-main-menu-item-dropdown') ) {

            // Verify if the dropdown is expanded
            if ( $(this).closest('div').hasClass('doc-main-menu-item-open') ) {

                // Remove doc-main-menu-item-expand class
                $this.closest('div').removeClass('doc-main-menu-item-expand');                

                // Hide
                $this.closest('div').find('> .doc-main-menu-items').slideUp('slow', function () {

                    // Remove doc-main-menu-item-open class
                    $this.closest('div').removeClass('doc-main-menu-item-open');

                });

            } else {

                // Add doc-main-menu-item-expand class
                $this.closest('div').addClass('doc-main-menu-item-expand');                

                // Show
                $this.closest('div').find('> .doc-main-menu-items').slideDown('slow', function () {

                    // Add doc-main-menu-item-open class
                    $this.closest('div').addClass('doc-main-menu-item-open');

                });

            }

        }
        
    });

    /*
     * Get the wanted page
     * 
     * @param object e with global object
     */ 
    $( document ).on( 'click', '.doc-page-show', function (e) {
        e.preventDefault();

        // Remove the selected class
        $('body .doc-page-show').removeClass('doc-main-menu-item-selected');

        // Add selected class
        $(this).addClass('doc-main-menu-item-selected');

        // Additional height
        var additional_height = 81;

        // Verify if is mobile view
        if ( $( window ).width() < 976 ) {

            // Set additional height
            additional_height = $('body .doc-sidebar-body').outerHeight() + 120;

        }
        
        // Scroll the page
        $('body .doc-articles').animate({
            scrollTop: (($($(this).attr('href')).offset().top + $('.doc-articles').scrollTop()) - additional_height)
        }, 500);
        
    });

});